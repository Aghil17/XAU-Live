# OANDA Gold Android

A minimal Android app that displays the current OANDA XAU/USD price.

## Important security note

This first version calls OANDA directly from Android. That means the OANDA personal access token is packaged into the application at build time. This is acceptable for a private prototype, but **not recommended for a public APK** because an APK can be inspected.

For a production/public release, use a small backend/proxy:
Android -> your backend -> OANDA
and keep the OANDA token only on the backend.

## OANDA setup

OANDA's v20 API requires an OANDA account and a personal access token. The official documentation says the token should be treated like a password.

The app requests:

GET /v3/accounts/{accountID}/pricing?instruments=XAU_USD

It calculates the displayed price as the midpoint of OANDA's returned bid and ask.

## Configure credentials

Add these properties to your user-level Gradle properties file:

OANDA_ACCOUNT_ID=YOUR_ACCOUNT_ID
OANDA_TOKEN=YOUR_PERSONAL_ACCESS_TOKEN
OANDA_BASE_URL=https://api-fxtrade.oanda.com

For an OANDA practice account use:

OANDA_BASE_URL=https://api-fxpractice.oanda.com

Then open the project in Android Studio and Sync/Run.

## Instrument availability

XAU_USD must be available to the OANDA account/division being used. OANDA documents that the instruments available depend on the account's regulatory division.

## Current behavior

- XAU/USD midpoint price
- Bid and Ask
- Live status
- Refresh every 2 seconds
- Offline/API error message
- Minimal Material 3 UI

## Production upgrade recommended

Replace polling with OANDA's pricing stream endpoint and put the OANDA token behind a backend service. The OANDA API documents a streaming pricing endpoint at:

/v3/accounts/{accountID}/pricing/stream
