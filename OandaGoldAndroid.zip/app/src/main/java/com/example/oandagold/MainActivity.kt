package com.example.oandagold

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

data class GoldQuote(
    val bid: Double,
    val ask: Double,
    val time: String,
    val connected: Boolean
) {
    val mid: Double get() = (bid + ask) / 2.0
}

class GoldRepository {
    private val client = OkHttpClient()
    private val jsonFormat = NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }

    suspend fun getQuote(): GoldQuote {
        val account = BuildConfig.OANDA_ACCOUNT_ID
        val token = BuildConfig.OANDA_TOKEN
        require(account.isNotBlank() && token.isNotBlank()) {
            "OANDA credentials are not configured."
        }

        val url = "${BuildConfig.OANDA_BASE_URL}/v3/accounts/$account/pricing?instruments=XAU_USD"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("OANDA HTTP ${response.code}: $body")
            }

            val root = JSONObject(body)
            val prices = root.getJSONArray("prices")
            require(prices.length() > 0) { "OANDA did not return XAU_USD." }

            val p = prices.getJSONObject(0)
            val bid = p.getJSONArray("bids").getJSONObject(0).getString("price").toDouble()
            val ask = p.getJSONArray("asks").getJSONObject(0).getString("price").toDouble()
            val time = p.optString("time", "")

            return GoldQuote(bid, ask, time, true)
        }
    }
}

class GoldViewModel : ViewModel() {
    private val repo = GoldRepository()
    var quote by mutableStateOf<GoldQuote?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var previousMid by mutableStateOf<Double?>(null)
        private set

    private var job: Job? = null

    init {
        start()
    }

    fun start() {
        if (job?.isActive == true) return
        job = viewModelScope.launch {
            while (isActive) {
                loading = quote == null
                try {
                    val next = repo.getQuote()
                    previousMid = quote?.mid
                    quote = next
                    error = null
                } catch (e: Exception) {
                    error = e.message ?: "Unable to receive price."
                } finally {
                    loading = false
                }
                delay(2000)
            }
        }
    }

    override fun onCleared() {
        job?.cancel()
        super.onCleared()
    }
}

@Composable
fun OandaGoldApp(vm: GoldViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val q = vm.quote
    val nf = NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            background = androidx.compose.ui.graphics.Color(0xFFFAFAF8),
            surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
            primary = androidx.compose.ui.graphics.Color(0xFF222222)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(28.dp))

                Text(
                    "GOLD",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp
                )
                Text(
                    "XAU / USD",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(64.dp))

                if (q != null) {
                    Text(
                        "$${nf.format(q.mid)}",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-1.5).sp
                    )

                    Spacer(Modifier.height(10.dp))

                    val delta = vm.previousMid?.let { q.mid - it }
                    val deltaText = delta?.let {
                        val sign = if (it >= 0) "+" else ""
                        "$sign${nf.format(it)}"
                    } ?: "—"

                    Text(
                        deltaText,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(36.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                "●  LIVE",
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(22.dp))

                    Text(
                        "Bid ${nf.format(q.bid)}   •   Ask ${nf.format(q.ask)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(8.dp))

                    Text(
                        "Source: OANDA",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    if (vm.loading) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.height(18.dp))
                    }
                    Text(
                        "Waiting for XAU/USD…",
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                vm.error?.let { message ->
                    Spacer(Modifier.height(32.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            message,
                            modifier = Modifier.padding(16.dp),
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(Modifier.weight(1f))

                Text(
                    "Updates every 2 seconds",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OandaGoldApp() }
    }
}
