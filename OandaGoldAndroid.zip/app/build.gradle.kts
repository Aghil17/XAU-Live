plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.oandagold"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.oandagold"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Put these in ~/.gradle/gradle.properties or this project's gradle.properties
    // before building. Never commit real credentials.
    defaultConfig {
        buildConfigField("String", "OANDA_ACCOUNT_ID", "\"${project.findProperty("OANDA_ACCOUNT_ID") ?: ""}\"")
        buildConfigField("String", "OANDA_TOKEN", "\"${project.findProperty("OANDA_TOKEN") ?: ""}\"")
        buildConfigField("String", "OANDA_BASE_URL", "\"${project.findProperty("OANDA_BASE_URL") ?: "https://api-fxtrade.oanda.com"}\"")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
